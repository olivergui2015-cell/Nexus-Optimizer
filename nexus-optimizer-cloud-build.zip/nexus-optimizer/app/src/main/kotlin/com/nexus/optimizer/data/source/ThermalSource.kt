package com.nexus.optimizer.data.source

import android.content.Context
import android.os.PowerManager
import com.nexus.optimizer.domain.model.ThermalLevel
import java.util.concurrent.Executor
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Estado térmico oficial (PowerManager, API 29+). Somente leitura:
 * o app não interfere em nenhum mecanismo de proteção térmica.
 */
class ThermalSource(context: Context) {
    private val powerManager: PowerManager? =
        context.getSystemService(PowerManager::class.java)

    fun observe(): Flow<ThermalLevel> = callbackFlow {
        val pm = powerManager
        if (pm == null) {
            trySend(ThermalLevel.UNKNOWN)
            awaitClose { }
            return@callbackFlow
        }
        trySend(pm.currentThermalStatus.toThermalLevel())
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            trySend(status.toThermalLevel())
        }
        val directExecutor = Executor { it.run() }
        pm.addThermalStatusListener(directExecutor, listener)
        awaitClose { pm.removeThermalStatusListener(listener) }
    }.distinctUntilChanged()

    private fun Int.toThermalLevel(): ThermalLevel = when (this) {
        PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NONE
        PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
        PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
        PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
        PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.CRITICAL
        PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalLevel.EMERGENCY
        PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.SHUTDOWN
        else -> ThermalLevel.UNKNOWN
    }
}
