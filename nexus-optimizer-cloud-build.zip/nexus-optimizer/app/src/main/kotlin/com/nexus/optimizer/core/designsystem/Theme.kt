package com.nexus.optimizer.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusColors.Cyan,
    onPrimary = Color(0xFF00232B),
    secondary = NexusColors.Violet,
    onSecondary = Color(0xFF1A0B3D),
    background = NexusColors.Background,
    onBackground = NexusColors.TextPrimary,
    surface = NexusColors.Surface,
    onSurface = NexusColors.TextPrimary,
    surfaceVariant = NexusColors.SurfaceElevated,
    onSurfaceVariant = NexusColors.TextSecondary,
    outline = NexusColors.TextSecondary,
    outlineVariant = NexusColors.Outline,
    error = NexusColors.StatusCritical,
)

/** Tema único e escuro (decisão da v0.1.0; tema claro não está planejado). */
@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = NexusTypography,
        content = content,
    )
}
