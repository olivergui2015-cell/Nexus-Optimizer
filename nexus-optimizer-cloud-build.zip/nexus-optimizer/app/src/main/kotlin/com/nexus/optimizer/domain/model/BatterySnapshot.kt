package com.nexus.optimizer.domain.model

enum class ChargeState { CHARGING, DISCHARGING, FULL, NOT_CHARGING, UNKNOWN }

enum class BatteryHealth { GOOD, OVERHEAT, DEAD, OVER_VOLTAGE, FAILURE, COLD, UNKNOWN }

data class BatterySnapshot(
    /** 0..100, ou null se o sistema não informou nível/escala válidos. */
    val levelPercent: Int?,
    val chargeState: ChargeState,
    /** Temperatura da bateria em °C, ou null se ausente. */
    val temperatureCelsius: Float?,
    val voltageMillivolts: Int?,
    val health: BatteryHealth,
)

/** Converte (level, scale) do broadcast de bateria em porcentagem. Null se inválido. */
fun batteryLevelPercent(level: Int, scale: Int): Int? =
    if (level < 0 || scale <= 0) null else (level * 100 / scale).coerceIn(0, 100)
