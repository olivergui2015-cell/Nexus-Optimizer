package com.nexus.optimizer.core.designsystem

import androidx.compose.ui.graphics.Color

object NexusColors {
    val Background = Color(0xFF0A0E14)
    val Surface = Color(0xFF111823)
    val SurfaceElevated = Color(0xFF182231)
    val Outline = Color(0xFF243044)

    val Cyan = Color(0xFF22D3EE)
    val Violet = Color(0xFF8B5CF6)

    val TextPrimary = Color(0xFFE6EDF3)
    val TextSecondary = Color(0xFF8B98A8)

    // Cores de status (usadas também junto de texto, nunca como único indicador).
    val StatusGood = Color(0xFF34D399)
    val StatusWarning = Color(0xFFFBBF24)
    val StatusCritical = Color(0xFFF87171)
}
