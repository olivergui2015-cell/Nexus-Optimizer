package com.nexus.optimizer

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.optimizer.core.designsystem.NexusTheme
import com.nexus.optimizer.feature.dashboard.DashboardRoute
import com.nexus.optimizer.feature.dashboard.DashboardViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Tema sempre escuro: barras do sistema transparentes com ícones claros.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val container = (application as NexusApp).container
        setContent {
            NexusTheme {
                val viewModel: DashboardViewModel =
                    viewModel(factory = DashboardViewModel.factory(container))
                DashboardRoute(viewModel)
            }
        }
    }
}
