package com.nexus.optimizer.domain.model

/** Estado térmico informado pelo sistema (PowerManager). Somente leitura. */
enum class ThermalLevel {
    NONE,
    LIGHT,
    MODERATE,
    SEVERE,
    CRITICAL,
    EMERGENCY,
    SHUTDOWN,
    UNKNOWN,
}
