package com.nexus.optimizer

import android.app.Application

class NexusApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
