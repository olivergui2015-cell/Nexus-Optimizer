package com.nexus.optimizer.domain.model

/** Leitura pontual de memória, vinda de ActivityManager.MemoryInfo. */
data class MemorySnapshot(
    val totalBytes: Long,
    val availableBytes: Long,
    val lowMemoryThresholdBytes: Long,
    val isLowMemory: Boolean,
) {
    val usedBytes: Long
        get() = (totalBytes - availableBytes).coerceAtLeast(0L)

    /** Fração usada em [0, 1]. Retorna 0 se o total for desconhecido. */
    val usedFraction: Float
        get() = if (totalBytes <= 0L) 0f else (usedBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
}
