package com.nexus.optimizer.domain.model

data class DashboardSnapshot(
    val memory: MemorySnapshot,
    val thermal: ThermalLevel,
    val battery: BatterySnapshot,
)
