package com.nexus.optimizer.feature.dashboard

import com.nexus.optimizer.domain.model.DashboardSnapshot
import com.nexus.optimizer.domain.model.DeviceSummary

data class DashboardUiState(
    val device: DeviceSummary,
    /** Null até a primeira leitura das três fontes. */
    val snapshot: DashboardSnapshot? = null,
    /** Frações de uso de RAM (0..1), da mais antiga para a mais recente. */
    val memoryHistory: List<Float> = emptyList(),
)
