package com.nexus.optimizer.data.repository

import com.nexus.optimizer.data.source.BatterySource
import com.nexus.optimizer.data.source.MemorySource
import com.nexus.optimizer.data.source.ThermalSource
import com.nexus.optimizer.domain.model.DashboardSnapshot
import com.nexus.optimizer.domain.model.DeviceSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class DashboardRepository(
    private val memorySource: MemorySource,
    private val thermalSource: ThermalSource,
    private val batterySource: BatterySource,
    val device: DeviceSummary,
) {
    /** Só emite depois que as três fontes entregaram a primeira leitura. */
    fun observe(): Flow<DashboardSnapshot> = combine(
        memorySource.observe(),
        thermalSource.observe(),
        batterySource.observe(),
    ) { memory, thermal, battery ->
        DashboardSnapshot(memory = memory, thermal = thermal, battery = battery)
    }
}
