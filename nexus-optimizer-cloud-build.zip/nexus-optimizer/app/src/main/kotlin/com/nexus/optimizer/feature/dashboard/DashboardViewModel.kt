package com.nexus.optimizer.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.nexus.optimizer.AppContainer
import com.nexus.optimizer.data.repository.DashboardRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(repository: DashboardRepository) : ViewModel() {

    private val initialState = DashboardUiState(device = repository.device)

    /**
     * A coleta só roda enquanto a UI está visível (WhileSubscribed + coleta ciente do ciclo de vida).
     * Se ficar mais de 5 s sem coletor, o histórico recomeça do zero (não há persistência na v0.1.0).
     */
    val uiState: StateFlow<DashboardUiState> = repository.observe()
        .scan(initialState) { state, snapshot ->
            // O combine reaproveita a mesma instância de memória quando só térmico/bateria mudam.
            // Só acrescentamos ao histórico quando há uma leitura de RAM realmente nova.
            val isNewMemorySample = snapshot.memory !== state.snapshot?.memory
            val history = if (isNewMemorySample) {
                (state.memoryHistory + snapshot.memory.usedFraction).takeLast(HISTORY_SIZE)
            } else {
                state.memoryHistory
            }
            state.copy(snapshot = snapshot, memoryHistory = history)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            initialValue = initialState,
        )

    companion object {
        private const val HISTORY_SIZE = 60
        private const val STOP_TIMEOUT_MS = 5_000L

        fun factory(container: AppContainer) = viewModelFactory {
            initializer { DashboardViewModel(container.dashboardRepository) }
        }
    }
}
