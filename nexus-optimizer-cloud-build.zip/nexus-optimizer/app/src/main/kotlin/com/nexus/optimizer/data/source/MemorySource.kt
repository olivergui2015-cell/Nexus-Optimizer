package com.nexus.optimizer.data.source

import android.app.ActivityManager
import android.content.Context
import com.nexus.optimizer.domain.model.MemorySnapshot
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Lê a memória do sistema via ActivityManager.getMemoryInfo() em intervalos fixos.
 * Não existe callback oficial para isso, então usamos polling enquanto houver coletor.
 */
class MemorySource(
    context: Context,
    private val intervalMs: Long = DEFAULT_INTERVAL_MS,
) {
    private val activityManager: ActivityManager? =
        context.getSystemService(ActivityManager::class.java)

    fun observe(): Flow<MemorySnapshot> = flow {
        while (true) {
            emit(read())
            delay(intervalMs)
        }
    }

    private fun read(): MemorySnapshot {
        val info = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(info)
        return MemorySnapshot(
            totalBytes = info.totalMem,
            availableBytes = info.availMem,
            lowMemoryThresholdBytes = info.threshold,
            isLowMemory = info.lowMemory,
        )
    }

    companion object {
        const val DEFAULT_INTERVAL_MS = 2_000L
    }
}
