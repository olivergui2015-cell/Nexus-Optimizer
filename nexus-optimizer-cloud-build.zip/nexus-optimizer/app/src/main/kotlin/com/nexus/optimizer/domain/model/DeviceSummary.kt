package com.nexus.optimizer.domain.model

data class DeviceSummary(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val apiLevel: Int,
    /** Build.SOC_MODEL (API 31+), ou null se indisponível. */
    val socModel: String?,
)
