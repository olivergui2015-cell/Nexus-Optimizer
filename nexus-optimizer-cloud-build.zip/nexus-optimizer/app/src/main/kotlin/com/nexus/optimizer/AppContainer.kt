package com.nexus.optimizer

import android.content.Context
import com.nexus.optimizer.data.repository.DashboardRepository
import com.nexus.optimizer.data.source.BatterySource
import com.nexus.optimizer.data.source.DeviceSource
import com.nexus.optimizer.data.source.MemorySource
import com.nexus.optimizer.data.source.ThermalSource

/**
 * Injeção de dependência manual. Hilt entra quando houver mais de uma feature
 * (ver docs/ARCHITECTURE.md).
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(
            memorySource = MemorySource(appContext),
            thermalSource = ThermalSource(appContext),
            batterySource = BatterySource(appContext),
            device = DeviceSource().read(),
        )
    }
}
