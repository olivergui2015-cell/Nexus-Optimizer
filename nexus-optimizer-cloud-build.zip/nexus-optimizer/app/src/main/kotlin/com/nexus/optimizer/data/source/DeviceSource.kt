package com.nexus.optimizer.data.source

import android.os.Build
import com.nexus.optimizer.domain.model.DeviceSummary

/** Informações estáticas básicas do aparelho, vindas de android.os.Build. */
class DeviceSource {
    fun read(): DeviceSummary = DeviceSummary(
        manufacturer = Build.MANUFACTURER.orEmpty(),
        model = Build.MODEL.orEmpty(),
        androidRelease = Build.VERSION.RELEASE.orEmpty(),
        apiLevel = Build.VERSION.SDK_INT,
        socModel = readSocModel(),
    )

    private fun readSocModel(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        val soc = Build.SOC_MODEL
        return soc.takeIf { it.isNotBlank() && !it.equals(Build.UNKNOWN, ignoreCase = true) }
    }
}
