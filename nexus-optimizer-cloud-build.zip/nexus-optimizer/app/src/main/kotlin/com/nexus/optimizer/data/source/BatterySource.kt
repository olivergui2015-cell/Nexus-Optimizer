package com.nexus.optimizer.data.source

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.nexus.optimizer.domain.model.BatteryHealth
import com.nexus.optimizer.domain.model.BatterySnapshot
import com.nexus.optimizer.domain.model.ChargeState
import com.nexus.optimizer.domain.model.batteryLevelPercent
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Bateria via broadcast oficial ACTION_BATTERY_CHANGED (sem permissão). */
class BatterySource(private val context: Context) {

    fun observe(): Flow<BatterySnapshot> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                trySend(intent.toBatterySnapshot())
            }
        }
        val sticky = ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        sticky?.let { trySend(it.toBatterySnapshot()) }
        awaitClose { context.unregisterReceiver(receiver) }
    }.distinctUntilChanged()

    private fun Intent.toBatterySnapshot(): BatterySnapshot {
        val level = getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val health = getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        // EXTRA_TEMPERATURE vem em décimos de °C.
        val temperature = if (hasExtra(BatteryManager.EXTRA_TEMPERATURE)) {
            getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        } else {
            null
        }
        val voltage = getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1).takeIf { it > 0 }

        return BatterySnapshot(
            levelPercent = batteryLevelPercent(level, scale),
            chargeState = status.toChargeState(),
            temperatureCelsius = temperature,
            voltageMillivolts = voltage,
            health = health.toBatteryHealth(),
        )
    }

    private fun Int.toChargeState(): ChargeState = when (this) {
        BatteryManager.BATTERY_STATUS_CHARGING -> ChargeState.CHARGING
        BatteryManager.BATTERY_STATUS_DISCHARGING -> ChargeState.DISCHARGING
        BatteryManager.BATTERY_STATUS_FULL -> ChargeState.FULL
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ChargeState.NOT_CHARGING
        else -> ChargeState.UNKNOWN
    }

    private fun Int.toBatteryHealth(): BatteryHealth = when (this) {
        BatteryManager.BATTERY_HEALTH_GOOD -> BatteryHealth.GOOD
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> BatteryHealth.OVERHEAT
        BatteryManager.BATTERY_HEALTH_DEAD -> BatteryHealth.DEAD
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> BatteryHealth.OVER_VOLTAGE
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> BatteryHealth.FAILURE
        BatteryManager.BATTERY_HEALTH_COLD -> BatteryHealth.COLD
        else -> BatteryHealth.UNKNOWN
    }
}
