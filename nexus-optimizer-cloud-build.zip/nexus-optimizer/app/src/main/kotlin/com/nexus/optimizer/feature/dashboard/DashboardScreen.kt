package com.nexus.optimizer.feature.dashboard

import android.text.format.Formatter
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.optimizer.R
import com.nexus.optimizer.core.designsystem.NexusColors
import com.nexus.optimizer.core.designsystem.NexusTheme
import com.nexus.optimizer.core.designsystem.component.CircularGauge
import com.nexus.optimizer.core.designsystem.component.NexusCard
import com.nexus.optimizer.core.designsystem.component.Sparkline
import com.nexus.optimizer.domain.model.BatteryHealth
import com.nexus.optimizer.domain.model.BatterySnapshot
import com.nexus.optimizer.domain.model.ChargeState
import com.nexus.optimizer.domain.model.DashboardSnapshot
import com.nexus.optimizer.domain.model.DeviceSummary
import com.nexus.optimizer.domain.model.MemorySnapshot
import com.nexus.optimizer.domain.model.ThermalLevel
import kotlin.math.roundToInt

@Composable
fun DashboardRoute(viewModel: DashboardViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    DashboardScreen(state)
}

@Composable
fun DashboardScreen(state: DashboardUiState, modifier: Modifier = Modifier) {
    Scaffold(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        val layoutDirection = LocalLayoutDirection.current
        val margin = 16.dp
        val fullWidth: LazyGridItemSpanScope.() -> GridItemSpan =
            { GridItemSpan(maxLineSpan) }

        // Em tablets a grade adaptativa coloca os cartões lado a lado.
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 320.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = innerPadding.calculateStartPadding(layoutDirection) + margin,
                top = innerPadding.calculateTopPadding() + margin,
                end = innerPadding.calculateEndPadding(layoutDirection) + margin,
                bottom = innerPadding.calculateBottomPadding() + margin,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item(span = fullWidth) { DashboardHeader() }

            val snapshot = state.snapshot
            if (snapshot == null) {
                item(span = fullWidth) {
                    Text(
                        text = stringResource(R.string.dashboard_loading),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                item { RamCard(snapshot.memory, state.memoryHistory) }
                item { ThermalCard(snapshot.thermal) }
                item { BatteryCard(snapshot.battery) }
            }
            item { DeviceCard(state.device) }
        }
    }
}

@Composable
private fun DashboardHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = "NEXUS",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = stringResource(R.string.dashboard_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun RamCard(memory: MemorySnapshot, history: List<Float>) {
    val context = LocalContext.current
    val used = Formatter.formatShortFileSize(context, memory.usedBytes)
    val total = Formatter.formatShortFileSize(context, memory.totalBytes)
    val available = Formatter.formatShortFileSize(context, memory.availableBytes)
    val percent = (memory.usedFraction * 100f).roundToInt()

    NexusCard(title = stringResource(R.string.card_ram)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            CircularGauge(
                fraction = memory.usedFraction,
                label = stringResource(R.string.value_percent, percent),
                color = if (memory.isLowMemory) NexusColors.StatusCritical else MaterialTheme.colorScheme.primary,
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.ram_used_of, used, total),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = stringResource(R.string.ram_available, available),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Sparkline(
            values = history,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        )
        Text(
            text = stringResource(R.string.ram_history_caption),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (memory.isLowMemory) {
            Text(
                text = stringResource(R.string.ram_low_warning),
                style = MaterialTheme.typography.bodyMedium,
                color = NexusColors.StatusCritical,
            )
        }
        Text(
            text = stringResource(R.string.ram_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ThermalCard(level: ThermalLevel) {
    NexusCard(title = stringResource(R.string.card_thermal)) {
        Text(
            text = stringResource(level.labelRes()),
            style = MaterialTheme.typography.titleLarge,
            color = level.statusColor(),
        )
        Text(
            text = stringResource(R.string.thermal_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun BatteryCard(battery: BatterySnapshot) {
    val unavailable = stringResource(R.string.value_unavailable)
    NexusCard(title = stringResource(R.string.card_battery)) {
        MetricRow(
            label = stringResource(R.string.battery_level),
            value = battery.levelPercent?.let { stringResource(R.string.value_percent, it) } ?: unavailable,
        )
        MetricRow(
            label = stringResource(R.string.battery_state),
            value = stringResource(battery.chargeState.labelRes()),
        )
        MetricRow(
            label = stringResource(R.string.battery_temperature),
            value = battery.temperatureCelsius?.let { stringResource(R.string.value_celsius, it) } ?: unavailable,
        )
        MetricRow(
            label = stringResource(R.string.battery_voltage),
            value = battery.voltageMillivolts?.let { stringResource(R.string.value_millivolts, it) } ?: unavailable,
        )
        MetricRow(
            label = stringResource(R.string.battery_health),
            value = stringResource(battery.health.labelRes()),
        )
    }
}

@Composable
private fun DeviceCard(device: DeviceSummary) {
    NexusCard(title = stringResource(R.string.card_device)) {
        MetricRow(
            label = stringResource(R.string.device_model),
            value = "${device.manufacturer} ${device.model}".trim(),
        )
        MetricRow(
            label = stringResource(R.string.device_android),
            value = stringResource(R.string.device_android_value, device.androidRelease, device.apiLevel),
        )
        MetricRow(
            label = stringResource(R.string.device_soc),
            value = device.socModel ?: stringResource(R.string.value_unavailable),
        )
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.End,
            modifier = Modifier
                .weight(1f, fill = false)
                .padding(start = 16.dp),
        )
    }
}

@StringRes
private fun ThermalLevel.labelRes(): Int = when (this) {
    ThermalLevel.NONE -> R.string.thermal_none
    ThermalLevel.LIGHT -> R.string.thermal_light
    ThermalLevel.MODERATE -> R.string.thermal_moderate
    ThermalLevel.SEVERE -> R.string.thermal_severe
    ThermalLevel.CRITICAL -> R.string.thermal_critical
    ThermalLevel.EMERGENCY -> R.string.thermal_emergency
    ThermalLevel.SHUTDOWN -> R.string.thermal_shutdown
    ThermalLevel.UNKNOWN -> R.string.thermal_unknown
}

/** Escolha visual de cor; o texto do estado sempre acompanha, a cor não é o único indicador. */
private fun ThermalLevel.statusColor(): Color = when (this) {
    ThermalLevel.NONE -> NexusColors.StatusGood
    ThermalLevel.LIGHT, ThermalLevel.MODERATE -> NexusColors.StatusWarning
    ThermalLevel.SEVERE,
    ThermalLevel.CRITICAL,
    ThermalLevel.EMERGENCY,
    ThermalLevel.SHUTDOWN,
    -> NexusColors.StatusCritical
    ThermalLevel.UNKNOWN -> NexusColors.TextSecondary
}

@StringRes
private fun ChargeState.labelRes(): Int = when (this) {
    ChargeState.CHARGING -> R.string.battery_state_charging
    ChargeState.DISCHARGING -> R.string.battery_state_discharging
    ChargeState.FULL -> R.string.battery_state_full
    ChargeState.NOT_CHARGING -> R.string.battery_state_not_charging
    ChargeState.UNKNOWN -> R.string.battery_state_unknown
}

@StringRes
private fun BatteryHealth.labelRes(): Int = when (this) {
    BatteryHealth.GOOD -> R.string.battery_health_good
    BatteryHealth.OVERHEAT -> R.string.battery_health_overheat
    BatteryHealth.DEAD -> R.string.battery_health_dead
    BatteryHealth.OVER_VOLTAGE -> R.string.battery_health_over_voltage
    BatteryHealth.FAILURE -> R.string.battery_health_failure
    BatteryHealth.COLD -> R.string.battery_health_cold
    BatteryHealth.UNKNOWN -> R.string.battery_health_unknown
}

// Dados abaixo são FICTÍCIOS e existem apenas para o Preview do Android Studio.
@Preview(name = "Dashboard (dados fictícios)", widthDp = 840, heightDp = 700, backgroundColor = 0xFF0A0E14, showBackground = true)
@Composable
private fun DashboardPreview() {
    NexusTheme {
        DashboardScreen(
            DashboardUiState(
                device = DeviceSummary("Preview", "Device", "14", 34, null),
                snapshot = DashboardSnapshot(
                    memory = MemorySnapshot(4_000_000_000L, 1_500_000_000L, 200_000_000L, false),
                    thermal = ThermalLevel.NONE,
                    battery = BatterySnapshot(80, ChargeState.DISCHARGING, 30.0f, 4000, BatteryHealth.GOOD),
                ),
                memoryHistory = listOf(0.5f, 0.55f, 0.6f, 0.58f, 0.62f, 0.625f),
            ),
        )
    }
}
