package com.nexus.optimizer.domain.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MemorySnapshotTest {

    @Test
    fun usedFraction_isUsedOverTotal() {
        val snapshot = MemorySnapshot(
            totalBytes = 1_000L,
            availableBytes = 250L,
            lowMemoryThresholdBytes = 100L,
            isLowMemory = false,
        )
        assertEquals(750L, snapshot.usedBytes)
        assertEquals(0.75f, snapshot.usedFraction, 0.0001f)
    }

    @Test
    fun usedFraction_isZero_whenTotalIsUnknown() {
        val snapshot = MemorySnapshot(0L, 0L, 0L, false)
        assertEquals(0f, snapshot.usedFraction, 0f)
    }

    @Test
    fun usedFraction_isZero_whenAvailableExceedsTotal() {
        val snapshot = MemorySnapshot(1_000L, 2_000L, 0L, false)
        assertEquals(0L, snapshot.usedBytes)
        assertEquals(0f, snapshot.usedFraction, 0f)
    }
}

class BatteryLevelPercentTest {

    @Test
    fun convertsLevelAndScaleToPercent() {
        assertEquals(50, batteryLevelPercent(level = 50, scale = 100))
        assertEquals(33, batteryLevelPercent(level = 1, scale = 3))
    }

    @Test
    fun returnsNull_whenLevelOrScaleIsInvalid() {
        assertNull(batteryLevelPercent(level = -1, scale = 100))
        assertNull(batteryLevelPercent(level = 10, scale = 0))
        assertNull(batteryLevelPercent(level = 10, scale = -1))
    }
}
