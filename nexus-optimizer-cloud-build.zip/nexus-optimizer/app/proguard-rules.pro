# Sem regras customizadas na v0.1.0 (sem reflexão, sem serialização).
