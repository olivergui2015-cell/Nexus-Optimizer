# Limitações técnicas

## Do que está implementado

- **RAM:** `ActivityManager.getMemoryInfo()` não tem callback, então a leitura é por polling (2 s).
  "Disponível" não é "livre": o Android usa memória sobrando como cache. Valor baixo é normal.
- **Térmico:** `PowerManager` informa só o *estado* (NONE…SHUTDOWN), não a temperatura de CPU/GPU.
  Requer API 29+.
- **Bateria:** temperatura e tensão vêm do broadcast `ACTION_BATTERY_CHANGED`; a precisão depende do
  fabricante. Temperatura é a da bateria, não do SoC.
- **SoC:** `Build.SOC_MODEL` só existe na API 31+; abaixo disso (ou se vier vazio/"unknown") mostramos "—".
  O que cada aparelho retorna **não foi verificado**.

## Fora de escopo por serem inacessíveis a apps comuns (sem root)

- Uso de CPU por núcleo e carga/frequência da GPU em tempo real (`/proc/stat` e `kgsl` bloqueados).
- Temperatura de CPU/GPU (`HardwarePropertiesManager` é restrito).
- FPS de outros aplicativos.
- Alterar governors, clocks ou perfis de desempenho.

## Princípios de segurança

- Nenhuma permissão declarada. Nenhuma escrita em configurações do sistema.
- O app não encerra processos, não limpa RAM e não interfere em proteção térmica.
- Nenhum ganho de FPS é prometido.
