# Arquitetura (v0.1.0)

MVVM com fluxo unidirecional de dados:

```
DashboardScreen  ←  DashboardViewModel (StateFlow<DashboardUiState>)
                          ↑
                  DashboardRepository  (combine de 3 fluxos)
                          ↑
     MemorySource (polling 2 s) · ThermalSource (listener) · BatterySource (broadcast) · DeviceSource (Build)
```

## Pacotes (`com.nexus.optimizer`)

- `core/designsystem`: tema escuro, tipografia, componentes (`NexusCard`, `CircularGauge`, `Sparkline`).
- `domain/model`: modelos puros de Kotlin (sem Android), testáveis em JVM.
- `data/source`: uma fonte por API do sistema, cada uma expõe `Flow`.
- `data/repository`: combina as fontes.
- `feature/dashboard`: estado, ViewModel e tela.

## Ajustes em relação ao plano aprovado

| Plano | Implementado | Motivo |
|---|---|---|
| Hilt | DI manual (`AppContainer`) | Só há uma feature. Hilt entra quando houver mais de uma, e adicionar KSP/Hilt sem poder compilar aumentava o risco sem benefício |
| Room / DataStore | Não incluídos | Não há persistência na v0.1.0; o histórico de RAM vive só na memória do ViewModel |
| Navegação adaptativa (rail/barra) | Não incluída | Há uma única tela. A grade do Dashboard já é adaptativa (`GridCells.Adaptive`) |
| Fontes Space Grotesk / JetBrains Mono | Fontes do sistema (sans / monospace) | Sem rede não dá para obter e empacotar as fontes |
| Nota de "saúde" explicável | Não incluída | Exige critérios validados em aparelho real; evitamos inventar limiares |

## Ciclo de vida da coleta

`stateIn(WhileSubscribed(5s))` + `collectAsStateWithLifecycle()`: as leituras só rodam com a tela visível.
Sem serviço em segundo plano. Se o app ficar mais de 5 s sem coletor, o histórico do gráfico recomeça.
