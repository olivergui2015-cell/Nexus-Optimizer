# Nexus Optimizer

App Android nativo (Kotlin · Jetpack Compose · Material 3 · MVVM · Gradle KTS) para
**monitoramento, diagnóstico e otimização segura**. Alvo inicial: Samsung Galaxy Tab A9+.

## Estado atual: v0.1.0 — somente Dashboard

| Item | Situação |
|---|---|
| Código-fonte do Dashboard (RAM, térmico, bateria, dispositivo) | Escrito |
| Compilado | **Não** (ambiente sem Android SDK, Gradle e rede) |
| Testes unitários executados | **Não** (escritos, nunca rodados) |
| Testado em aparelho | **Não** |
| Outros módulos (Game Mode, Performance Analyzer...) | Não iniciados, por decisão |

## Como compilar (na sua máquina, com internet)

1. Abra a pasta no Android Studio (versão recente com suporte ao AGP 8.7). Ele cria o `local.properties`,
   baixa o Gradle 8.9 (definido em `gradle/wrapper/gradle-wrapper.properties`) e sincroniza.
   - Sem Android Studio: instale o Android SDK, crie `local.properties` com `sdk.dir=/caminho/do/sdk`
     e rode `gradle wrapper` uma vez para gerar `gradlew` e `gradle-wrapper.jar`
     (esses dois não puderam ser gerados aqui).
2. Requisitos: JDK 17+, Android SDK Platform 35.
3. `./gradlew testDebugUnitTest` e `./gradlew assembleDebug`.

> As versões em `gradle/libs.versions.toml` são conhecidas e compatíveis entre si, mas **não foram
> verificadas contra os repositórios**. Se o sync reclamar, atualize para as versões estáveis atuais.

## Documentação

- `docs/ARCHITECTURE.md`: arquitetura e decisões.
- `docs/LIMITATIONS.md`: limitações técnicas das APIs Android.
